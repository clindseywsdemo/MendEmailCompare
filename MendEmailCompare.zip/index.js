import run from './dist/compareEmailsToHashed.js';

run(process.argv);